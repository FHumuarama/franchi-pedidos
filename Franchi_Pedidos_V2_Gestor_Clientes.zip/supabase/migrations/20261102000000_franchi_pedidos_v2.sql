-- Franchi Pedidos · atualização aditiva compatível com banco existente
-- Só o administrador (Edge Function com service_role) cadastra lojas.
-- Não apaga empresas, usuários, pedidos nem produtos existentes.
DROP POLICY IF EXISTS stores_insert_owner ON public.stores;
DROP POLICY IF EXISTS stores_delete_owner ON public.stores;

-- Endpoints expostos usam a RLS já existente de stores, products e categories.
-- Garanta somente os privilégios necessários para uso no navegador.
REVOKE INSERT, UPDATE, DELETE ON public.stores FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.products, public.categories FROM anon;
GRANT SELECT ON public.stores, public.products, public.categories TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.products, public.categories TO authenticated;
GRANT UPDATE ON public.stores TO authenticated;
GRANT SELECT ON public.orders TO authenticated;

-- Fotos dos produtos: leitura pública; apenas titular da loja pode subir/apagar.
INSERT INTO storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
VALUES ('produtos','produtos',true,5242880,ARRAY['image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "franchi_produtos_public_read" ON storage.objects;
CREATE POLICY "franchi_produtos_public_read" ON storage.objects
FOR SELECT TO anon,authenticated
USING (bucket_id='produtos');

DROP POLICY IF EXISTS "franchi_produtos_upload_owner" ON storage.objects;
CREATE POLICY "franchi_produtos_upload_owner" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id='produtos' AND EXISTS (
  SELECT 1 FROM public.stores s
  WHERE s.owner_id=(SELECT auth.uid()) AND storage.objects.name LIKE s.id::text || '/%'
));

DROP POLICY IF EXISTS "franchi_produtos_delete_owner" ON storage.objects;
CREATE POLICY "franchi_produtos_delete_owner" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id='produtos' AND EXISTS (
  SELECT 1 FROM public.stores s
  WHERE s.owner_id=(SELECT auth.uid()) AND storage.objects.name LIKE s.id::text || '/%'
));
